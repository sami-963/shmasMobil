
import React from "react";
import "./coursesHeroSection.css";
import { Link } from "react-router-dom";


export default function CoursesHeroSection({
  containerClass,
  image,
  title,
  description,
  buttonText,
  subtext,
  imageClass
  }) {
  return (
    <div className="coursesHero">
     
        <div className={`courses-image-content ${containerClass || ""}`}>
        {/* النصوص */}
         <div className="courses-hero-content">
          <h1 className="courses-hero-title">{title}</h1>
          <p className="courses-hero-description">{description}</p>
            <Link to="/" className="courses-hero-btn">
            {buttonText}
            </Link>
            <div className="courses-hero-line"></div>
            <p className="courses-hero-subtext">
             {subtext}
            </p>
          </div>
          {/* الصورة */}
           <div className={`courses-hero-image ${imageClass || ""}`}>
            <img 
              src={image} 
              alt="hero visual" 
            />
          </div>

          </div>
         
    </div>
  );
}


