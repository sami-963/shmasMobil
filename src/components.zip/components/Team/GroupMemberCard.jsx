import { FaArrowLeft, FaInstagram, FaLinkedinIn, FaWhatsapp } from "react-icons/fa";

import "../../pages/Team/Team.css"
function GroupMemberCard({ img, text, title }) {

    return <div className="GroupMember1">
        <div className="GroupMemberImg-div">
            <img className="GroupMemberImg" src={img} alt={img} />
        </div>
        <div className="GroubMember1-div">
            <p className="title1">{title}</p>
            {/* <p className="text">{text}</p> */}
            <div className="icon-div">
                <FaInstagram  className="icons"/>
                <FaLinkedinIn className="icons"/>
                <FaWhatsapp   className="icons" />
            </div>
            {/* <div className="BlogDiv2-div-1">
                <p className="BlogCard-p4">اقرأ المزيد</p>
                <FaArrowLeft className="ArrowIcon" />
            </div> */}
        </div>
    </div>
}
export default GroupMemberCard