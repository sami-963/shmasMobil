import "./ShareOpinionCard.css"
import generalCardImg from "../../../public/3dCard-removebg-preview.png"
import { Link } from "react-router-dom";

export default function ShareOpinionCard(){
    return(
        <>
            <div className="ShareOpinionCard container flex">
              <div className="sectionImg">
                <img src={generalCardImg} alt="generalImg"  className="subsucribeFirstImg"/>
              </div>
              <div className="cardContent flex">
                  <div className="smallTitle">
                    <span>شارك رأيك</span>
                  </div>
                  <div className="sectionMainTitle">
                    <h2>دعونا نتحدث عن التعليم والتطوير</h2>
                  </div>
                  <div className="sectionDescription">
                    <p> نحن نؤمن بأن التعلم المستمر هو الطريق للنمو الشخصي والمهني، 
                      وأن مشاركة الأفكار والتجارب تصنع مجتمعًا أكثر وعيًا وإبداعًا. 
                      من خلال منصتنا نسعى لتقديم محتوى واضح وفعّال يساعدك على تطوير مهاراتك، 
                      ويمنحك الفرصة للتفاعل مع الآخرين، وتبادل المعرفة التي تفتح آفاقًا جديدة 
                      نحو مستقبل أفضل للجميع.</p>
                  </div>

                  <Link to="/contact" className="contactUs">
                    <button>تواصل معنا</button>
                  </Link>
              </div>
              <div className="sectionImg">
                <img src={generalCardImg} alt="generalImg"  className="subsucribeLastImg" />
              </div>
            </div>
        </>
    )
}
