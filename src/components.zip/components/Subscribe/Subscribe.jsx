import "../Subscribe/Subscribe.css"
import threeDCardImg from "../../../public/3dCard-removebg-preview.png"

export default function Subscribe(){
    return (
        <>
            <section className="subscribeSection container flex">
              <div className="sectionImg">
                <img src={threeDCardImg} alt="threeDDesignImg"  className="subsucribeFirstImg"/>
              </div>
                <div className="subsucriptionCardContent">
                  <div className="smallTitle">
                      <span>انضم إلينا</span>
                  </div>
                  <div className="sectionMainTitle">
                    <h2>اشترك في تحديثات منصّة التعلم</h2>
                  </div>
                  <div className="sectionDescription">
                    <p>
                      انضم إلى منصتنا التعليمية واحصل على أحدث الدروس والمقالات والنصائح التي تساعدك على تطوير مهاراتك في مختلف المجالات.
                      من خلال اشتراكك ستصلك تحديثات منتظمة حول الدورات الجديدة، العروض الخاصة، والمحتوى المميز المصمم خصيصًا لدعم رحلتك التعليمية خطوة بخطوة.
                    </p>
                  </div>
      
                  <div className="emailContainer flex">
                      <input type="email" placeholder="أدخل بريدك الإلكتروني" required/>
                      <button type="submit">اشترك الآن</button>
                  </div>
                </div>
                <div className="sectionImg">
                  <img src={threeDCardImg} alt="threeDDesignImg"  className="subsucribeLastImg" />
                </div>
            </section>
        </>
    )
}
